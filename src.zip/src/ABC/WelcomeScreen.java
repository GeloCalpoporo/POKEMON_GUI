package ABC;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.CountDownLatch;

public class WelcomeScreen extends JFrame {
    private CountDownLatch latch = new CountDownLatch(1);

    public WelcomeScreen() {
        initGUI();
    }

    private void initGUI() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(52, 152, 219)); // Background color

        // Create a welcome label with a colorful font
        JLabel welcomeLabel = new JLabel("Welcome to Pokémon!");
        welcomeLabel.setFont(new Font("Press Start 2P", Font.BOLD, 32));
        welcomeLabel.setForeground(new Color(255, 255, 255)); // White text color
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Create a "Press to Start" button with colorful styling
        JButton startButton = new JButton("Press to Start");
        startButton.setFont(new Font("Press Start 2P", Font.PLAIN, 18));
        startButton.setBackground(new Color(241, 196, 15)); // Yellow button background
        startButton.setForeground(new Color(44, 62, 80)); // Dark blue button text color

        // Add components to the panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(52, 152, 219)); // Match background color
        panel.add(Box.createVerticalGlue());
        panel.add(welcomeLabel);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(startButton);
        panel.add(Box.createVerticalGlue());

        add(panel, BorderLayout.CENTER);

        // Add action listener to the "Press to Start" button
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Close the welcome screen and proceed to the main game view
                dispose();
                GameModel model = new GameModel();
                GameController controller = new GameController(model, new GameView(model, new GameController(model, null)));
                controller.pickStarterCreature();
            }
        });

        // Set frame properties
        setTitle("Welcome to Pokémon!");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    // Method to wait for the "Press to Start" button to be pressed
    public void waitForStart() {
        try {
            latch.await(); // This will block until the latch is counted down
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
